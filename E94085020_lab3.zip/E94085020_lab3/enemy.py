import pygame
import math
import os
from settings import PATH,PATH_2, GREEN, RED

pygame.init()
ENEMY_IMAGE = pygame.image.load(os.path.join("images", "enemy.png"))


class Enemy:
    def __init__(self,wave):#設定輸入值wave,可以控制病毒的生成位置與移動路徑
        self.width = 40
        self.height = 50
        self.image = pygame.transform.scale(ENEMY_IMAGE, (self.width, self.height))
        self.health = 5
        self.max_health = 10
        if(wave==0):
            self.path=PATH#若wave為0,使用路徑1
        else:    
            self.path = PATH_2#若wave為1,使用路徑2
        self.path_pos = 0
        self.move_count = 0
        self.stride = 1
        self.x, self.y = self.path[0]
        

    def draw(self, win):
        # draw enemy
        win.blit(self.image, (self.x - self.width // 2, self.y - self.height // 2))
        # draw enemy health bar
        self.draw_health_bar(win)

    def draw_health_bar(self, win):
        pygame.draw.rect(win,GREEN,[self.x - self.width // 2,self.y+15-self.height,4*self.health,5])
        #hp條設定於病毒上面15unit處,綠色hp條為剩餘生命的長度是self.health的4倍                                                                                     
        pygame.draw.rect(win,RED,[(self.x - self.width // 2)+(4*self.health),self.y+15-self.height,4*(self.max_health-self.health),5])
        #紅色hp條為已損失生命,長度為(self.max_health-self.health)的4倍
        """
        Draw health bar on an enemy
        :param win: window
        :return: None
        """
        # ...(to be done)

    def move(self):
        if(self.path_pos==len(self.path)-1):#self.path_pos記錄當前病毒處於路徑中第幾個坐標,當病毒位於最後一個坐標時將不在移動
            pass
        elif(self.path_pos<len(self.path)-1):#若病毒還未到達最後一個坐標,則往下一個坐標移動
            stride = 1
            ax,ay=self.path[self.path_pos] #當前坐標
            bx,by=self.path[self.path_pos+1]#移動目的地坐標
            distance_A_B = math.sqrt((ax - bx)**2 + (ay - by)**2)
            max_count = int(distance_A_B / stride)  # total footsteps that needed from A to B
            unit_vector_x = (bx - ax) / distance_A_B
            unit_vector_y = (by - ay) / distance_A_B
            delta_x = unit_vector_x * stride
            delta_y = unit_vector_y * stride
             # update the coordinate and the counter
            self.x += delta_x
            self.y += delta_y
            self.move_count += 1#記錄坐標間移動所走的步數
            if(self.move_count==max_count):
                self.path_pos+=1 #當已完成坐標間移動所需的步數時,會以抵達的坐標為起點繼續往下一個坐標移動
                self.move_count=0#步數將會先歸零
        """ 
        Enemy move toward path points every frame
        :return: None
        """     

class EnemyGroup:
    def __init__(self):
        self.gen_count = 0
        self.gen_period = 120   # (unit: frame)
        self.reserved_members = []
        self.expedition = []  # don't change this line until you do the EX.3 
        self.clock = pygame.time.Clock()
        self.wave=0#控制病毒移動路徑
        self.count_frame=0#記錄幀數
        self.num=0#記錄所需放出病毒的數量
    def campaign(self):
        """
        Send an enemy to go on an expedition once 120 frame
        :return: None
        """
        if(self.reserved_members):#先判斷self.reservedd_members是否為空陣列
            if(self.count_frame%self.gen_period==0):#程式會先放出一個病毒,之後每進過120幀再放出一個病毒(120和240時)
               self.expedition.append(self.reserved_members.pop())#將Enemy從self.reserved_members中移除并放入self.expedition
        self.count_frame+=1
        if(self.count_frame==self.num*self.gen_period):#當病毒以全部放出時,將self.count_frame歸零
           self.count_frame=0

    def generate(self, num):
        """
        Generate the enemies in this wave
        :param num: enemy number
        :return: None
        """
        self.num=num-1
        for i in range(0,num):
            self.reserved_members.append(Enemy(self.wave%2)) 
        self.wave+=1
        
    def get(self):
        """
        Get the enemy list
        """
        return self.expedition

    def is_empty(self):
        """
        Return whether the enemy is empty (so that we can move on to next wave)
        """
        return False if self.reserved_members else True

    def retreat(self, enemy):
        """
        Remove the enemy from the expedition
        :param enemy: class Enemy()
        :return: None
        """
        self.expedition.remove(enemy)





